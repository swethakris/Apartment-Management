///////////////////////////////////////////////////////////////////////////////
// ALL STUDENTS COMPLETE THESE SECTIONS
// Title: Programming Project - 2
// Files: State.java, TestState.java 
// Semester: Spring 2016
//
// Author: Swetha Krishnakumar,Giridharan Rajagopalan	
// Email: sxk151530@utdallas.edu,gxr151330@utdallas.edu
// CS Login: sxk151530,gxr151330
// Lecturer's Name: Nassim Sohaee
// Course Section: MIS 6323.501 Object Oriented Programming

//import section
import java.util.Scanner;


public class TestApartment {
	/**
   	* Method to get check for apartments
   	* Extracts only the required apartments based on user's minimum criteria
   	* @return - boolean
   	*/
	public static boolean CheckApartment(Apartment apt,int aptNumOfBed,int aptNumOfBath,double aptRent)
	{
		boolean result = false;

		if(aptNumOfBed <= apt.getAptNumOfBed() && aptNumOfBath <= apt.getAptNumOfBath() && aptRent >= apt.getAptRentAmount())
		{
			System.out.printf("The apartment with following specifications is available\n Apartment Number : %d\n Number of Bedrooms : %d\n Number of Bathrooms : %d\n Rent amount : %.2f\n ", apt.getAptNum(),apt.getAptNumOfBed(),apt.getAptNumOfBath(),apt.getAptRentAmount());
			result = true;
		}
		else
			result = false;

		return result;
	
	}
	
	/**
   	* Method to sort apartments in ascending order of rent
   	* Swap positions whenever applicable based on rent
   	* @return - none
   	*/
	public static void SortApartments(Apartment[] apt)
	{
	  Apartment temp = new Apartment();

	  for(int i =0 ; i< apt.length;i++)
		{
		  for(int j = i + 1; j < apt.length; j++)
    	  {
			if(apt[i].getAptRentAmount() > apt[j].getAptRentAmount())
			{
				temp = apt[j];
				apt[j] = apt[i];
				apt[i]= temp;
			}
    	  }
		}
	}
	
	/**
   	* Main method to get input from user and check for apartments
   	*
   	* @return - none
   	*/
	public static void main(String[] args) {
		// TODO Auto-generated method stub		
		int aptNumOfBedInput,aptNumOfBathInput,count=0;
		double aptRentInput;
		
		//get input from user using Scanner util
		Scanner input = new Scanner(System.in);
		
		System.out.println("Enter number of bedrooms required");
		aptNumOfBedInput = input.nextInt();		
		System.out.println("Enter number of bathrooms required");
		aptNumOfBathInput = input.nextInt();	
		System.out.println("Enter rent amount willing to pay");
		aptRentInput = input.nextDouble();	
		
		Apartment[] apt = new Apartment[5];
		
		//instantiate objects with different values
		apt[0] = new Apartment(1,3,2,12000);
		apt[1] = new Apartment(2,4,2,15000);
		apt[2] = new Apartment(3,2,1,8000);
		apt[3] = new Apartment(4,5,3,25000);
		apt[4] = new Apartment(5,1,1,5000);
		
		//call SortApartments method to sort apartments
		SortApartments(apt);
		
		for(int i = 0; i < apt.length;i++)
		{						
		if(CheckApartment(apt[i],aptNumOfBedInput,aptNumOfBathInput,aptRentInput))
			count ++;
		}
		
		if(count == 0)
			System.out.print("No such apartments available");
	}
	
}
