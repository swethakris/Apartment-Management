///////////////////////////////////////////////////////////////////////////////
// ALL STUDENTS COMPLETE THESE SECTIONS
// Title: Programming Project - 2
// Files: State.java, TestState.java 
// Semester: Spring 2016
//
// Author: Swetha Krishnakumar,Giridharan Rajagopalan	
// Email: sxk151530@utdallas.edu,gxr151330@utdallas.edu
// CS Login: sxk151530,gxr151330
// Lecturer's Name: Nassim Sohaee
// Course Section: MIS 6323.501 Object Oriented Programming
//
/**
* The class Apartment consists of 2 constructors(default and parameterized) to set and get field values.
*
* @author Swetha Krishnakumar,Giridharan Rajagopalan
*/

public class Apartment {
	//declare apartment attributes
   private int aptNum;
   private int aptNumBed;
   private int aptNumBath;
   private double aptRent;
   
 
 //Method type : Default
 	//Method description
 	/**
 	* This is the apartment default constructor.
 	*
 	* @return - none
 	*/
 	
 	public Apartment()
 	{
 		
 	}
   
 //Method type : Parameterized
   //Method description
	/**
	* This is the state parameterized constructor which takes 6 inputs and assigns the values 
	* to the respective fields
	*
	* @param (aptNumber) (apartment number is passed as input parameter)
  	* @param (aptNumBedroom) (apartment number of bedrooms is passed as input parameter)
  	* @param (aptNumBathroom) (apartment number of bathrooms is passed as input parameter)
  	* @param (aptRentAmount) (apartment rent amount is passed as input parameter)
	* @return - none
	*/
   public Apartment(int aptNumber,int aptNumBedroom,int aptNumBathroom,double aptRentAmount)
   {
	   aptNum = aptNumber;
	   aptNumBed = aptNumBedroom;
	   aptNumBath = aptNumBathroom;
	   aptRent = aptRentAmount;
	   
   }
 
   /**
  	* Get method for returning apartment number
  	*
  	* @return apartment number
  	*   	*/
   public int getAptNum()
   {
	   return aptNum;
   }
   
   /**
  	* Get method for returning apartment bedroom number
  	*
  	* @return apartment number of bedrooms
  	*/
   public int getAptNumOfBed()
   {
	   return aptNumBed;
   }
   
   /**
  	* Get method for returning apartment bathroom number
  	*
  	* @return apartment number of bathrooms
  	*/
   public int getAptNumOfBath()
   {
	   return aptNumBath;
   }
   
   /**
  	* Get method for returning apartment rent amount
  	*
  	* @return rent amount
  	*/
   public double getAptRentAmount()
   {
	   return aptRent;
   }
   
}
